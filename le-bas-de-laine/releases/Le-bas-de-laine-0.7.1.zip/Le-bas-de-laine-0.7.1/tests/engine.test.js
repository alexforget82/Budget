import test from "node:test";
import assert from "node:assert/strict";
import { simulate, bankBalance, cardLots } from "../engine.js";
import { periodStart, nextPeriod, occurrences } from "../dates.js";
import { cents } from "../service.js";
const reference = "2026-10-22";
const base = () => ({
  accounts: [
    { id: 1, kind: "bank", name: "Conjoint", is_main: 1 },
    { id: 2, kind: "card", name: "CIBC" },
  ],
  categories: [
    {
      id: 1,
      name: "Épicerie",
      limit_cents: 23000,
      period: "weekly",
      renewal_day: 4,
      active: 1,
      starts_on: "2026-10-15",
    },
  ],
  transactions: [],
  transfers: [],
  checkpoints: [
    { id: 1, account_id: 1, seq: 1, amount_cents: 100000, date: reference },
  ],
  recurrences: [
    {
      id: 1,
      name: "Paie",
      kind: "income",
      account_id: 1,
      amount_cents: 100000,
      frequency: "biweekly",
      start_on: "2026-10-23",
      active: 1,
    },
  ],
  occurrence_states: [],
});
const buy = (n = -7169, account = 2, extra = {}) => ({
  id: 1,
  seq: 2,
  account_id: account,
  category_id: 1,
  amount_cents: n,
  date: reference,
  description: "Épicerie",
  ...extra,
});
const at = (sim, date) => sim.daily.find((d) => d.date === date);
test("1000 bank, 230 groceries, 71.69 card: available stays 770", () => {
  const s = base(),
    before = simulate(s, reference);
  assert.equal(before.available_cents, 77000);
  s.transactions.push(buy());
  const after = simulate(s, reference);
  assert.equal(after.available_cents, 77000);
  assert.equal(after.bank_cents, 100000);
  assert.equal(after.card_cents, 7169);
  assert.equal(after.categories[0].current.remaining_cents, 15831);
  assert.equal(
    after.breakdown.bank_cents -
      after.breakdown.cards_cents -
      after.breakdown.bills_cents -
      after.breakdown.limits_cents,
    after.available_cents,
  );
});
test("bank purchase moves cash and remaining limit once", () => {
  const s = base();
  s.transactions.push(buy(-7169, 1));
  const sim = simulate(s, reference);
  assert.equal(sim.available_cents, 77000);
  assert.equal(sim.bank_cents, 92831);
  assert.equal(sim.card_cents, 0);
});
test("all Thursdays before payday protect their full new period", () => {
  const s = base();
  s.recurrences[0].start_on = "2026-11-06";
  s.transactions.push(buy());
  const sim = simulate(s, reference);
  assert.equal(at(sim, "2026-10-22").safe_cents, 77000);
  assert.equal(at(sim, "2026-10-29").safe_cents, 54000);
  assert.equal(at(sim, "2026-11-05").safe_cents, 31000);
  assert.equal(sim.available_cents, 31000);
  assert.equal(sim.bank_cents, 100000);
});
test("early card purchase reduces next Thursday, retaining actual date", () => {
  const s = base();
  s.categories[0].starts_on = "2026-10-22";
  s.transactions.push(
    buy(-7169, 2, { date: "2026-10-21", period_on: "2026-10-22" }),
  );
  const sim = simulate(s, "2026-10-21");
  assert.equal(sim.daily[0].safe_cents, 92831);
  assert.equal(at(sim, "2026-10-22").safe_cents, 77000);
  assert.equal(sim.available_cents, 77000);
  assert.equal(s.transactions[0].date, "2026-10-21");
});
test("partial, full and excess payments release protection once", () => {
  for (const [payment, safe, held] of [
    [2000, 77000, 5169],
    [7169, 77000, 0],
    [10000, 74169, 0],
  ]) {
    const s = base();
    s.transactions.push(buy());
    s.transfers.push({
      id: 1,
      seq: 3,
      from_account_id: 1,
      to_account_id: 2,
      amount_cents: payment,
      date: reference,
    });
    const sim = simulate(s, reference);
    assert.equal(sim.bank_cents, 100000 - payment);
    assert.equal(sim.card_cents, held);
    assert.equal(sim.available_cents, safe);
  }
});
test("unbudgeted card purchase stays protected", () => {
  const s = base();
  s.transactions.push(buy(-10000, 2, { category_id: null }));
  assert.equal(simulate(s, reference).available_cents, 67000);
});
test("payments release only the intended card", () => {
  const s = base();
  s.accounts.push({ id: 3, kind: "card" });
  s.transactions.push(
    buy(-10000, 2, { category_id: null }),
    buy(-5000, 3, { id: 2, seq: 3, category_id: null }),
  );
  s.transfers.push({
    id: 1,
    seq: 4,
    from_account_id: 1,
    to_account_id: 2,
    amount_cents: 10000,
  });
  assert.equal(
    cardLots(s).reduce((n, l) => n + l.remaining_cents, 0),
    5000,
  );
  assert.equal(cardLots(s)[0].account_id, 3);
});
test("checkpoint includes everything entered before regardless of same-day date", () => {
  const s = base();
  s.transactions.push(buy(-10000, 1, { category_id: null }));
  assert.equal(bankBalance(s), 90000);
  s.checkpoints.push({
    id: 2,
    seq: 3,
    account_id: 1,
    amount_cents: 90000,
    date: reference,
  });
  assert.equal(bankBalance(s), 90000);
  s.transactions.push(buy(-2000, 1, { id: 2, seq: 4, category_id: null }));
  assert.equal(bankBalance(s), 88000);
});
test("historical bank import changes category usage without another debit", () => {
  const s = base();
  s.transactions.push(buy(-7169, 1, { included: 1 }));
  const sim = simulate(s, reference);
  assert.equal(sim.bank_cents, 100000);
  assert.equal(sim.available_cents, 84169);
});
test("checkpoint never clears unpaid card purchases", () => {
  const s = base();
  s.transactions.push(buy());
  s.checkpoints.push({
    id: 2,
    seq: 4,
    account_id: 1,
    amount_cents: 100000,
    date: reference,
  });
  assert.equal(simulate(s, reference).card_cents, 7169);
});
test("overdue bills persist, postponement changes the day, cancellation resolves", () => {
  const s = base();
  s.recurrences.push({
    id: 2,
    name: "Hydro",
    kind: "expense",
    account_id: 1,
    amount_cents: 10000,
    frequency: "monthly",
    one_time: 1,
    start_on: "2026-10-20",
    active: 1,
  });
  assert.equal(simulate(s, reference).available_cents, 67000);
  s.occurrence_states.push({
    rule_id: 2,
    original_on: "2026-10-20",
    status: "postponed",
    postponed_on: "2026-10-26",
  });
  assert.equal(simulate(s, reference).available_cents, 77000);
  s.occurrence_states[0].status = "cancelled";
  assert.equal(simulate(s, reference).available_cents, 77000);
});
test("paying a bill replaces its forecast, allowing actual amount adjustment", () => {
  const s = base();
  s.recurrences.push({
    id: 2,
    name: "Hydro",
    kind: "expense",
    account_id: 1,
    amount_cents: 10000,
    frequency: "monthly",
    one_time: 1,
    start_on: reference,
    active: 1,
  });
  assert.equal(simulate(s, reference).available_cents, 67000);
  s.transactions.push(buy(-9000, 1, { category_id: null }));
  s.occurrence_states.push({
    rule_id: 2,
    original_on: reference,
    status: "paid",
    transaction_id: 1,
  });
  assert.equal(simulate(s, reference).available_cents, 68000);
});
test("future card bill plus repayment never double charges", () => {
  const s = base();
  s.recurrences.push(
    {
      id: 2,
      name: "Apple",
      kind: "expense",
      account_id: 2,
      amount_cents: 5398,
      frequency: "monthly",
      one_time: 1,
      start_on: reference,
      active: 1,
    },
    {
      id: 3,
      name: "Paiement",
      kind: "transfer",
      account_id: 1,
      to_account_id: 2,
      amount_cents: 5398,
      frequency: "monthly",
      one_time: 1,
      start_on: reference,
      active: 1,
    },
  );
  const sim = simulate(s, reference);
  assert.equal(sim.available_cents, 71602);
  assert.equal(sim.daily[0].card_cents, 0);
  assert.equal(sim.daily[0].cash_cents, 94602);
});
test("income expected today is unavailable until receipt", () => {
  const s = base();
  s.recurrences[0].start_on = reference;
  const sim = simulate(s, reference);
  assert.equal(sim.daily[0].cash_cents, 100000);
  assert.equal(
    sim.upcoming.find((e) => e.kind === "income").awaiting_receipt,
    true,
  );
});
test("available before payday and minimum on 90 days are separate", () => {
  const s = base();
  s.recurrences[0].amount_cents = 10000;
  const sim = simulate(s, reference);
  assert.equal(sim.daily.length, 90);
  assert.equal(sim.available_cents, 77000);
  assert.ok(sim.minimum_cents < 77000);
  assert.throws(() => simulate(s, reference, 91));
});
test("weekly and monthly boundaries include leap year", () => {
  const c = { period: "monthly", renewal_day: 31 };
  assert.equal(periodStart(c, "2028-02-29"), "2028-02-29");
  assert.equal(nextPeriod(c, "2028-02-29"), "2028-03-31");
  assert.equal(
    periodStart({ period: "weekly", renewal_day: 4 }, "2026-10-21"),
    "2026-10-15",
  );
});
test("actual biweekly dates count 3 October paychecks and 2 November paychecks", () => {
  const r = {
    id: 1,
    name: "Paie",
    kind: "income",
    amount_cents: 116805,
    frequency: "biweekly",
    start_on: "2026-10-02",
  };
  assert.equal(occurrences(r, "2026-10-01", "2026-10-31").length, 3);
  assert.equal(occurrences(r, "2026-11-01", "2026-11-30").length, 2);
});
test("historical paid purchases and refunds never erase new card protections", () => {
  const s = base();
  s.card_baseline_seq = 5;
  s.transactions.push(
    buy(-10000, 2, { settled_cents: 10000 }),
    buy(5000, 2, { id: 2, seq: 3 }),
    buy(-4000, 2, { id: 3, seq: 6, category_id: null }),
  );
  s.transfers.push({
    id: 1,
    seq: 4,
    to_account_id: 2,
    from_account_id: 1,
    amount_cents: 99999,
    included: 1,
  });
  assert.equal(simulate(s, reference).card_cents, 4000);
});
test("fractional cents are rejected without rounding", () => {
  assert.equal(cents("1 168,05"), 116805);
  assert.equal(cents("0"), 0);
  assert.equal(cents("-71.69"), -7169);
  for (const n of ["1.005", "NaN", "1e6", "12,5,0", ""])
    assert.throws(() => cents(n));
});
test("pure simulation preserves inputs and reconciles every day", () => {
  const s = base();
  s.transactions.push(buy());
  const before = structuredClone(s),
    sim = simulate(s, reference);
  assert.deepEqual(s, before);
  for (const d of sim.daily)
    assert.equal(d.cash_cents - d.card_cents - d.limits_cents, d.safe_cents);
});
test("a bill after day 30 triggers the 90-day warning without changing money available before pay", () => {
  const s = base();
  s.categories = [];
  s.recurrences[0].amount_cents = 20000;
  s.recurrences[0].one_time = 1;
  s.recurrences.push({
    id: 2,
    name: "Taxes de janvier",
    kind: "expense",
    account_id: 1,
    amount_cents: 200000,
    frequency: "yearly",
    one_time: 1,
    start_on: "2027-01-12",
    active: 1,
  });
  const short = simulate(s, reference, 30),
    long = simulate(s, reference, 90);
  assert.equal(long.available_cents, short.available_cents);
  assert.equal(long.until, short.until);
  assert.deepEqual(long.breakdown, short.breakdown);
  assert.equal(long.daily.length, 90);
  assert.equal(long.minimum_on, "2027-01-12");
  assert.equal(long.minimum_cents, -80000);
  assert.equal(long.risk.below_available, true);
  assert.equal(long.risk.bills[0].name, "Taxes de janvier");
});
test("a distant payday still leaves the spending window capped at its unchanged 30 days", () => {
  const s = base();
  s.recurrences[0].start_on = "2026-12-15";
  const short = simulate(s, reference, 30),
    long = simulate(s, reference);
  assert.equal(long.until, "2026-11-20");
  assert.equal(long.available_cents, short.available_cents);
  assert.deepEqual(long.breakdown, short.breakdown);
});
test("protected limit explanation adds current remaining and each renewal, net of assigned early purchases", () => {
  const s = base();
  s.recurrences[0].start_on = "2026-11-06";
  s.transactions.push(buy());
  const sim = simulate(s, reference),
    detail = sim.limits_details;
  assert.equal(detail.total_cents, 61831);
  assert.equal(detail.total_cents, sim.breakdown.limits_cents);
  assert.deepEqual(
    detail.categories[0].periods.map((p) => [p.kind, p.remaining_cents]),
    [
      ["current", 15831],
      ["renewal", 23000],
      ["renewal", 23000],
    ],
  );
  assert.equal(
    detail.categories
      .flatMap((c) => c.periods)
      .reduce((n, p) => n + p.remaining_cents, 0),
    detail.total_cents,
  );
});
test("Autres cushions unbudgeted spending but excludes known bills and income without recategorizing purchases", () => {
  const s = base();
  s.categories.push(
    {
      id: 2,
      name: "Autres",
      limit_cents: 5000,
      period: "monthly",
      renewal_day: 1,
      starts_on: "2026-10-01",
      active: 1,
    },
    { id: 3, name: "Maison", limit_cents: null, active: 1 },
    { id: 4, name: "Factures", limit_cents: null, active: 1 },
  );
  s.fallback_category_id = 2;
  const before = simulate(s, reference);
  assert.equal(before.available_cents, 72000);
  s.transactions.push(buy(-2000, 1, { category_id: 3 }));
  const after = simulate(s, reference);
  assert.equal(after.available_cents, 72000);
  assert.equal(
    after.categories.find((c) => c.id === 2).current.remaining_cents,
    3000,
  );
  assert.equal(s.transactions[0].category_id, 3);
  s.transactions.push(buy(-1000, 1, { id: 2, seq: 3, category_id: 4 }));
  s.occurrence_states.push({
    rule_id: 99,
    original_on: reference,
    status: "paid",
    transaction_id: 2,
  });
  s.transactions.push(buy(10000, 1, { id: 3, seq: 4, category_id: null }));
  assert.equal(
    simulate(s, reference).categories.find((c) => c.id === 2).current
      .remaining_cents,
    3000,
  );
});
test("unclassified card purchase consumes Autres without deducting its protected money twice", () => {
  const s = base();
  s.categories.push({
    id: 2,
    name: "Autres",
    limit_cents: 5000,
    period: "monthly",
    renewal_day: 1,
    starts_on: "2026-10-01",
    active: 1,
  });
  s.fallback_category_id = 2;
  const before = simulate(s, reference);
  s.transactions.push(buy(-2000, 2, { category_id: null }));
  const after = simulate(s, reference);
  assert.equal(before.available_cents, 72000);
  assert.equal(after.available_cents, 72000);
  assert.equal(after.bank_cents, 100000);
  assert.equal(after.card_cents, 2000);
  assert.equal(
    after.categories.find((c) => c.id === 2).current.remaining_cents,
    3000,
  );
});

test("future purchase simulation respects date and category protection on bank and card", () => {
  const s = base();
  const original = JSON.stringify(s),
    ref = simulate(s, reference);
  for (const account_id of [1, 2]) {
    const on = "2026-10-24";
    const trial = simulate(s, reference, 90, {
      amount_cents: 7169,
      date: on,
      account_id,
      category_id: 1,
      period_on: "2026-10-22",
    });
    assert.equal(trial.available_cents, ref.available_cents);
    assert.deepEqual(
      trial.daily.map((d) => d.safe_cents),
      ref.daily.map((d) => d.safe_cents),
    );
    const unplanned = simulate(s, reference, 90, {
      amount_cents: 1000,
      date: on,
      account_id,
      category_id: null,
      period_on: on,
    });
    for (let i = 0; i < ref.daily.length; i++)
      assert.equal(
        unplanned.daily[i].safe_cents,
        ref.daily[i].safe_cents - (ref.daily[i].date >= on ? 1000 : 0),
      );
  }
  assert.equal(JSON.stringify(s), original);
});
test("secondary savings is excluded from spendable bank balance and tracks transfers independently", () => {
  const s = base();
  s.accounts.push({ id: 3, kind: "bank", name: "Épargne", is_main: 0 });
  s.checkpoints.push({
    account_id: 3,
    seq: 2,
    amount_cents: 50000,
    date: reference,
  });
  assert.equal(bankBalance(s, 3), 50000);
  assert.equal(bankBalance(s), 100000);
  s.transfers.push({
    seq: 3,
    from_account_id: 1,
    to_account_id: 3,
    amount_cents: 10000,
  });
  assert.equal(bankBalance(s, 3), 60000);
  assert.equal(bankBalance(s), 90000);
});

test("shifted salary and bill enter the forecast exactly once on the effective business day", () => {
  const s = base();
  s.categories = [];
  s.recurrences = [
    {
      id: 8,
      name: "Paie samedi",
      kind: "income",
      amount_cents: 10000,
      account_id: 1,
      start_on: "2026-10-24",
      frequency: "monthly",
      day_adjust: "before",
      active: 1,
      one_time: 1,
    },
    {
      id: 9,
      name: "Facture dimanche",
      kind: "expense",
      amount_cents: 4000,
      account_id: 1,
      start_on: "2026-10-25",
      frequency: "monthly",
      day_adjust: "after",
      active: 1,
      one_time: 1,
    },
  ];
  const trial = simulate(s, reference);
  assert.equal(
    trial.daily.find((d) => d.date === "2026-10-23").cash_cents,
    110000,
  );
  assert.equal(
    trial.daily.find((d) => d.date === "2026-10-25").cash_cents,
    110000,
  );
  assert.equal(
    trial.daily.find((d) => d.date === "2026-10-26").cash_cents,
    106000,
  );
  assert.equal(trial.daily.flatMap((d) => d.events).length, 2);
  assert.equal(
    trial.daily.flatMap((d) => d.events).find((e) => e.rule_id === 9)
      .nominal_on,
    "2026-10-25",
  );
});

test("first bill adjusted before nominal start remains protected when overdue or postponed", () => {
  for (const account_id of [1, 2]) {
    const s = base();
    s.categories = [];
    s.recurrences = [
      {
        id: 9,
        name: "Facture",
        kind: "expense",
        account_id,
        amount_cents: 10000,
        frequency: "monthly",
        start_on: "2026-11-01",
        day_adjust: "before",
        one_time: 1,
        active: 1,
      },
    ];
    const overdue = simulate(s, "2026-11-02");
    assert.equal(overdue.available_cents, 90000);
    assert.equal(overdue.daily[0].events[0].original_on, "2026-10-30");
    s.occurrence_states = [
      {
        rule_id: 9,
        original_on: "2026-10-30",
        status: "postponed",
        postponed_on: "2026-11-04",
        amount_cents: 12000,
      },
    ];
    const postponed = simulate(s, "2026-11-02");
    assert.equal(postponed.available_cents, 88000);
    assert.equal(at(postponed, "2026-11-04").events.length, 1);
    for (const status of ["paid", "cancelled"]) {
      s.occurrence_states[0].status = status;
      assert.equal(simulate(s, "2026-11-02").available_cents, 100000);
    }
  }
});

test("audit every weekly renewal and monthly limit remains protected with and without carry", () => {
  for (const carry of [false, true])
    for (let weekday = 0; weekday < 7; weekday++) {
      const s = base();
      s.recurrences = [];
      s.categories[0].renewal_day = weekday;
      s.categories[0].starts_on = periodStart(s.categories[0], "2026-11-01");
      s.categories.push({
        id: 2,
        name: "Maison",
        limit_cents: 12000,
        period: "monthly",
        renewal_day: 1,
        active: 1,
        starts_on: "2026-11-01",
      });
      if (carry) s.weekly_rollover_from = "2026-11-01";
      const result = simulate(s, "2026-11-01", 90);
      let expected = 0;
      const allocations = new Map();
      for (const c of s.categories) {
        let day = periodStart(c, "2026-11-01");
        while (day <= "2027-01-29") {
          const applied = day < "2026-11-01" ? "2026-11-01" : day;
          allocations.set(
            applied,
            (allocations.get(applied) || 0) + c.limit_cents,
          );
          day = nextPeriod(c, day);
        }
      }
      for (const day of result.daily) {
        expected += allocations.get(day.date) || 0;
        assert.equal(
          day.limits_cents,
          expected,
          `${weekday}/${carry}/${day.date}`,
        );
        assert.equal(day.safe_cents, 100000 - expected);
      }
      assert.equal(
        result.available_cents,
        Math.min(...result.daily.slice(0, 30).map((d) => d.safe_cents)),
      );
      assert.equal(
        result.minimum_cents,
        Math.min(...result.daily.map((d) => d.safe_cents)),
      );
    }
});

test("30-day headline protects bills after a small next income and exposes an exact breakdown", () => {
  const s = base();
  s.categories = [
    {
      id: 1,
      name: "Maison",
      limit_cents: 10000,
      period: "monthly",
      renewal_day: 1,
      starts_on: "2026-11-01",
      active: 1,
    },
    {
      id: 2,
      name: "Épicerie",
      limit_cents: 5000,
      period: "weekly",
      renewal_day: 4,
      starts_on: "2026-11-05",
      active: 1,
    },
  ];
  s.recurrences = [
    {
      id: 1,
      name: "Allocation",
      kind: "income",
      account_id: 1,
      amount_cents: 10000,
      frequency: "monthly",
      start_on: "2026-11-02",
      one_time: 1,
      active: 1,
    },
    {
      id: 2,
      name: "Paie",
      kind: "income",
      account_id: 1,
      amount_cents: 100000,
      frequency: "monthly",
      start_on: "2026-11-08",
      one_time: 1,
      active: 1,
    },
    {
      id: 3,
      name: "Facture",
      kind: "expense",
      account_id: 1,
      amount_cents: 50000,
      frequency: "monthly",
      start_on: "2026-11-04",
      one_time: 1,
      active: 1,
    },
  ];
  const before = simulate(s, "2026-11-01");
  assert.equal(before.available_cents, 90000);
  assert.equal(before.spending_30.amount_cents, 45000);
  assert.equal(before.spending_30.minimum_on, "2026-11-05");
  assert.equal(before.spending_30.days, 30);
  assert.equal(before.spending_30.until, "2026-11-30");
  for (const account_id of [1, 2]) {
    const state = structuredClone(s);
    state.transactions.push(
      buy(-7000, account_id, { date: "2026-11-01", period_on: "2026-11-01" }),
    );
    const result = simulate(state, "2026-11-01").spending_30;
    assert.equal(result.amount_cents, 45000);
    const b = result.breakdown;
    assert.equal(
      b.bank_cents - b.cards_cents - b.bills_cents - b.limits_cents,
      result.amount_cents,
    );
    assert.equal(
      result.limits_details.categories
        .flatMap((c) => c.periods)
        .reduce((n, p) => n + p.remaining_cents, 0),
      b.limits_cents,
    );
    if (account_id === 2) {
      state.transfers.push({
        id: 1,
        seq: 3,
        from_account_id: 1,
        to_account_id: 2,
        amount_cents: 7000,
        date: "2026-11-01",
        included: 0,
      });
      assert.equal(
        simulate(state, "2026-11-01").spending_30.amount_cents,
        45000,
      );
    }
  }
  assert.equal(simulate(s, "2026-11-01", 1).spending_30.days, 1);
});
