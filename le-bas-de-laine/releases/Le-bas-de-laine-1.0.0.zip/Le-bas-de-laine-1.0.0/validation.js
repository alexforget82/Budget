import { normalizeMerchant } from "./classification.js";
import { validDate } from "./dates.js";
export function validateState(s) {
  if (s.weekly_rollover_from != null && !validDate(s.weekly_rollover_from))
    throw Error("Date d’activation des reports invalide.");
  if (
    s.fallback_category_id !== undefined &&
    s.fallback_category_id !== null &&
    (!Number.isSafeInteger(s.fallback_category_id) ||
      !s.categories.some((c) => c.id === s.fallback_category_id))
  )
    throw Error("Catégorie coussin invalide.");
  const integer = (n, label) => {
    if (!Number.isSafeInteger(n) || Math.abs(n) > 1e12)
      throw Error("Entier monétaire invalide : " + label);
  };
  const date = (d, label) => {
    if (!validDate(d)) throw Error("Date invalide : " + label);
  };
  const sequences = new Set();
  for (const table of ["transactions", "transfers", "checkpoints"])
    for (const row of s[table]) {
      integer(row.seq, "ordre");
      if (row.seq < 1 || sequences.has(row.seq))
        throw Error("Ordre de saisie ambigu.");
      sequences.add(row.seq);
      date(row.date, table);
    }
  if (
    s.accounts.filter((a) => a.is_main).length > 1 ||
    s.accounts.some((a) => a.is_main && a.kind !== "bank")
  )
    throw Error("Compte principal invalide.");
  for (const a of s.accounts) {
    integer(a.opening_card_cents, "protection");
    if (a.opening_card_cents < 0) throw Error("Protection négative.");
  }
  for (const t of s.transactions) {
    integer(t.amount_cents, "transaction");
    integer(t.settled_cents, "paiement");
    if (
      !t.amount_cents ||
      t.settled_cents < 0 ||
      t.settled_cents > Math.abs(t.amount_cents) ||
      ![0, 1].includes(t.included) ||
      (t.reviewed !== undefined && ![0, 1].includes(t.reviewed))
    )
      throw Error("Transaction invalide.");
    if (t.period_on) date(t.period_on, "période");
  }
  for (const t of s.transfers) {
    integer(t.amount_cents, "virement");
    if (t.amount_cents <= 0 || ![0, 1].includes(t.included))
      throw Error("Virement invalide.");
  }
  for (const t of s.checkpoints) integer(t.amount_cents, "point de contrôle");
  for (const c of s.categories)
    if (c.limit_cents !== null) {
      integer(c.limit_cents, "limite");
      if (
        c.limit_cents < 0 ||
        !["weekly", "monthly", "semimonthly"].includes(c.period) ||
        !Number.isInteger(c.renewal_day) ||
        c.renewal_day < (c.period === "weekly" ? 0 : 1) ||
        c.renewal_day > (c.period === "weekly" ? 6 : 31)
      )
        throw Error("Limite invalide.");
      if (
        c.period === "semimonthly" &&
        (c.renewal_day > 27 ||
          !Number.isInteger(c.renewal_day2) ||
          c.renewal_day2 <= c.renewal_day ||
          c.renewal_day2 > 31)
      )
        throw Error("Deuxième renouvellement invalide.");
      if (c.starts_on) date(c.starts_on, "début");
    }
  for (const r of s.recurrences) {
    integer(r.amount_cents, "facture");
    date(r.start_on, "récurrence");
    if (
      r.frequency === "semimonthly" &&
      (+r.start_on.slice(8) > 27 ||
        !Number.isInteger(r.second_day) ||
        r.second_day <= +r.start_on.slice(8) ||
        r.second_day > 31)
    )
      throw Error("Deuxième jour de facture invalide.");
    if (
      r.frequency === "semimonthly" &&
      r.day_adjust !== "none" &&
      (r.second_day - +r.start_on.slice(8) < 7 ||
        28 - r.second_day + +r.start_on.slice(8) < 7)
    )
      throw Error(
        "Jours de facture trop proches pour le déplacement des fériés.",
      );
    if (
      r.amount_cents <= 0 ||
      ![
        "weekly",
        "biweekly",
        "semimonthly",
        "monthly",
        "quarterly",
        "semiannual",
        "yearly",
        "last_day",
        "last_business_day",
        "rrq",
      ].includes(r.frequency) ||
      !["none", "before", "after"].includes(r.day_adjust)
    )
      throw Error("Récurrence invalide.");
  }
  for (const r of s.rules || []) {
    if (
      !Number.isSafeInteger(r.priority) ||
      r.priority < 0 ||
      r.priority > 100000 ||
      !["contains", "starts", "equals"].includes(r.match_type) ||
      typeof r.pattern !== "string" ||
      !normalizeMerchant(r.pattern) ||
      r.pattern.length > 200 ||
      !["expense", "income"].includes(r.direction) ||
      ![0, 1].includes(r.active) ||
      !s.categories.some((c) => c.id === r.category_id) ||
      (r.account_id !== null && !s.accounts.some((a) => a.id === r.account_id))
    )
      throw Error("Règle de classement invalide.");
    for (const value of [r.min_cents, r.max_cents])
      if (value !== null) {
        integer(value, "borne de règle");
        if (value < 0) throw Error("Borne négative.");
      }
    if (
      r.min_cents !== null &&
      r.max_cents !== null &&
      r.min_cents > r.max_cents
    )
      throw Error("Bornes inversées.");
  }
  for (const o of s.occurrence_states) {
    date(o.original_on, "échéance");
    if (o.postponed_on) date(o.postponed_on, "report");
    if (o.amount_cents !== null) integer(o.amount_cents, "échéance");
  }
}
